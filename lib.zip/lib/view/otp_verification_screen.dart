// ══════════════════════════════════════════════════════════════════════════════
// OTP VERIFICATION SCREEN
// ══════════════════════════════════════════════════════════════════════════════
 
import 'package:construction_app/view/registration_screen.dart';
import 'package:construction_app/widgets/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pinput/pinput.dart';


class OTPVerificationScreen extends StatefulWidget {
  final String phoneNumber;
 
  const OTPVerificationScreen({super.key, required this.phoneNumber});
 
  @override
  State<OTPVerificationScreen> createState() => _OTPVerificationScreenState();
}
 
class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  final _otpController = TextEditingController();
  bool _isLoading = false;
  int _resendTimer = 30;
 
  @override
  void initState() {
    super.initState();
    _startResendTimer();
  }
 
  void _startResendTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted && _resendTimer > 0) {
        setState(() => _resendTimer--);
        _startResendTimer();
      }
    });
  }
 
  Future<void> _verifyOTP() async {
    if (_otpController.text.length != 6) {
      _showSnackbar('Please enter complete OTP', isError: true);
      return;
    }
 
    setState(() => _isLoading = true);
 
    try {
      // TODO: Implement your OTP verification API call
      // await yourAuthService.verifyOTP(widget.phoneNumber, _otpController.text);
 
      await Future.delayed(const Duration(seconds: 1)); // Simulating API call
 
      if (!mounted) return;
 
      // Navigate to Registration
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => CompanyRegisterScreen()
        ),
      );
    } catch (e) {
      _showSnackbar('Invalid OTP. Please try again.', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
 
  void _showSnackbar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.poppins(fontSize: 13)),
        backgroundColor: isError ? AppColors.red : AppColors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
 
  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 60,
      textStyle: GoogleFonts.poppins(
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: AppColors.dark,
      ),
      decoration: BoxDecoration(
        color: AppColors.greyFill,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
    );
 
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.dark),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
 
              // Title
              Text('Enter OTP',
                  style: GoogleFonts.poppins(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: AppColors.dark,
                  )),
              const SizedBox(height: 8),
              Text.rich(
                TextSpan(
                  text: 'We\'ve sent a 6-digit code to\n',
                  style: GoogleFonts.poppins(fontSize: 14, color: AppColors.grey),
                  children: [
                    TextSpan(
                      text: '+91 ${widget.phoneNumber}',
                      style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: AppColors.dark,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
 
              // OTP Input
              Center(
                child: Pinput(
                  controller: _otpController,
                  length: 6,
                  defaultPinTheme: defaultPinTheme,
                  focusedPinTheme: defaultPinTheme.copyWith(
                    decoration: defaultPinTheme.decoration!.copyWith(
                      border: Border.all(color: AppColors.amber, width: 2),
                    ),
                  ),
                  onCompleted: (_) => _verifyOTP(),
                ),
              ),
              const SizedBox(height: 32),
 
              // Resend OTP
              Center(
                child: _resendTimer > 0
                    ? Text('Resend OTP in $_resendTimer seconds',
                        style: GoogleFonts.poppins(
                            fontSize: 13, color: AppColors.grey))
                    : TextButton(
                        onPressed: () {
                          setState(() => _resendTimer = 30);
                          _startResendTimer();
                          _showSnackbar('OTP sent successfully');
                        },
                        child: Text('Resend OTP',
                            style: GoogleFonts.poppins(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: AppColors.amber)),
                      ),
              ),
              const SizedBox(height: 24),
 
              // Verify Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _verifyOTP,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.amber,
                    foregroundColor: AppColors.dark,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation(AppColors.dark),
                          ),
                        )
                      : Text('Verify & Continue',
                          style: GoogleFonts.poppins(
                              fontSize: 16, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
 
  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }
}