import 'package:construction_app/view/otp_verification_screen.dart';
import 'package:construction_app/widgets/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
 
// ══════════════════════════════════════════════════════════════════════════════
// 1. PHONE VERIFICATION SCREEN
// ══════════════════════════════════════════════════════════════════════════════
 
class PhoneVerificationScreen extends StatefulWidget {
  const PhoneVerificationScreen({super.key});
 
  @override
  State<PhoneVerificationScreen> createState() =>
      _PhoneVerificationScreenState();
}
 
class _PhoneVerificationScreenState extends State<PhoneVerificationScreen> {
  final _phoneController = TextEditingController();
  final _nameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
 
  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }
 
  Future<void> _sendOTP() async {
    if (!_formKey.currentState!.validate()) return;
 
    setState(() => _isLoading = true);
 
    try {
      // TODO: Implement your OTP API call here
      // await yourAuthService.sendOTP(_phoneController.text);
 
      await Future.delayed(const Duration(seconds: 1)); // Simulating API call
 
      if (!mounted) return;
 
      // Navigate to OTP verification
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OTPVerificationScreen(
            phoneNumber: _phoneController.text,
          ),
        ),
      );
    } catch (e) {
      _showSnackbar('Failed to send OTP. Please try again.', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
 
  void _showSnackbar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.poppins(fontSize: 13)),
        backgroundColor: isError ? AppColors.red : AppColors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
 
                // Logo/Icon
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.amber,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.phone_android,
                        size: 48, color: AppColors.white),
                  ),
                ),
                const SizedBox(height: 32),
 
                // Title
                Text('Verify Your Phone',
                    style: GoogleFonts.poppins(
                      fontSize: 26,
                      fontWeight: FontWeight.w700,
                      color: AppColors.dark,
                    )),
                const SizedBox(height: 8),
                Text(
                    'We\'ll send you a one-time password to verify your phone number',
                    style: GoogleFonts.poppins(
                        fontSize: 14, color: AppColors.grey)),
                const SizedBox(height: 40),
                // Contact Person Name
                Text('Contact Person',
                    style: GoogleFonts.poppins(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.dark)),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _nameController,
                  keyboardType: TextInputType.text,
                  maxLength: 10,
                  style: GoogleFonts.poppins(fontSize: 16),
                  decoration: InputDecoration(
                    prefixIcon:
                        const Icon(Icons.person, color: AppColors.amber),
                    hintText: 'Enter your name',
                    hintStyle: GoogleFonts.poppins(
                        fontSize: 14, color: AppColors.greyLight),
                    filled: true,
                    fillColor: AppColors.greyFill,
                    counterText: '',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: AppColors.amber, width: 2),
                    ),
                  ),
                  //inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                ),
                // Phone Number Input
                SizedBox(height: 20),

                Text('Phone Number',
                    style: GoogleFonts.poppins(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.dark)),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  style: GoogleFonts.poppins(fontSize: 16),
                  decoration: InputDecoration(
                    prefixIcon:
                        const Icon(Icons.phone, color: AppColors.amber),
                    hintText: 'Enter 10-digit mobile number',
                    hintStyle: GoogleFonts.poppins(
                        fontSize: 14, color: AppColors.greyLight),
                    filled: true,
                    fillColor: AppColors.greyFill,
                    counterText: '',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: AppColors.amber, width: 2),
                    ),
                  ),
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your phone number';
                    }
                    if (value.length != 10) {
                      return 'Phone number must be 10 digits';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 32),
 
                // Send OTP Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _sendOTP,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.amber,
                      foregroundColor: AppColors.dark,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor:
                                  AlwaysStoppedAnimation(AppColors.dark),
                            ),
                          )
                        : Text('Send OTP',
                            style: GoogleFonts.poppins(
                                fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(height: 24),
 
                // Terms & Conditions
                Center(
                  child: Text.rich(
                    TextSpan(
                      text: 'By continuing, you agree to our ',
                      style: GoogleFonts.poppins(
                          fontSize: 12, color: AppColors.grey),
                      children: [
                        TextSpan(
                          text: 'Terms & Conditions',
                          style: GoogleFonts.poppins(
                              fontSize: 12,
                              color: AppColors.amber,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}