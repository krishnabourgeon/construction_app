import 'package:construction_app/models/models.dart';
import 'package:construction_app/view/company/dashboard_screen.dart';
import 'package:construction_app/view/company/labour_screen.dart';
import 'package:construction_app/view/company/materials_screen.dart';
import 'package:construction_app/view/company/site_list_screen.dart';
import 'package:construction_app/view/company/supplier_screen.dart';
import 'package:construction_app/view/company/user_screen.dart';
import 'package:construction_app/widgets/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';


class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
   // final List<Site> sites = getSampleSites();
  int _currentIndex = 0;
    void changeTab(int index) {
    setState(() => _currentIndex = index);
  }

  late final _screens = [
    DashboardScreen(onNavigate: changeTab),
    const SupplierScreen(),
    const UserScreen(),
    const SitesScreen(),
    
    // ViewMaterialsScreen(sites: sites),
    // ViewLabourScreen(sites: sites),
  ];

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: AppColors.navy,
      statusBarIconBrightness: Brightness.light,
    ));
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.navy,
          border: Border(top: BorderSide(color: Color(0xFF2D2D44), width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (i) => setState(() => _currentIndex = i),
          backgroundColor: AppColors.navy,
          selectedItemColor: AppColors.amber,
          unselectedItemColor: AppColors.grey,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: GoogleFonts.poppins(
              fontSize: 10, fontWeight: FontWeight.w600),
          unselectedLabelStyle:
              GoogleFonts.poppins(fontSize: 10),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home_rounded),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person_rounded),
              label: 'Supplier',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person_rounded),
              label: 'Supervisor',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.domain_outlined),
              activeIcon: Icon(Icons.domain_rounded),
              label: 'Sites',
            ),
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.inventory_2_outlined),
            //   activeIcon: Icon(Icons.inventory_2_rounded),
            //   label: 'Materials',
            // ),
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.people_alt_outlined),
            //   activeIcon: Icon(Icons.people_alt_rounded),
            //   label: 'Labour',
            // ),
          ],
        ),
      ),
    );
  }
}
